This is a translation of the Arduino sketch located in the MPU-9250 repository for the MPU-9250 9-axis motion sensor with 9 DoF sensor fusion using open-source Madgwick and Mahony algorithms and an STM32F401 M4 Cortex microprocessor. 

The programs were compiled using the mbed compiler and achieve sensor fusion filter update rates of 4870 Hz operating the STM32F401 at 84 MHz.
