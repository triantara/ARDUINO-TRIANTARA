/*
  Fontname: -FreeType-04b03b-Medium-R-Normal--8-80-72-72-P-39-ISO10646-1
  Copyright: 19992003 / yuji oshimo�o / 04@dsg4.com / www.04.jp.org
  Capital A Height: 0, '1' Height: 5
  Calculated Max Values w= 5 h= 5 x= 0 y= 2 dx= 6 dy= 0 ascent= 5 len= 5
  Font Bounding box     w= 5 h= 6 x= 0 y=-1
  Calculated Min Values           x= 0 y=-1 dx= 0 dy= 0
  Pure Font   ascent = 5 descent= 0
  X Font      ascent = 5 descent= 0
  Max Font    ascent = 5 descent=-1
*/
#include "u8g.h"
const u8g_fntpgm_uint8_t u8g_font_04b_03bn[136] U8G_FONT_SECTION("u8g_font_04b_03bn") = {
  1,5,6,0,255,5,0,0,0,0,42,58,0,5,255,5,
  0,4,51,67,160,64,160,3,51,67,64,224,64,1,34,50,
  64,128,4,49,65,224,2,17,33,128,2,85,101,8,16,32,
  64,128,2,69,85,240,144,144,144,240,2,37,53,192,64,64,
  64,64,2,69,85,240,16,240,128,240,2,69,85,240,16,240,
  16,240,2,69,85,144,144,144,240,16,2,69,85,240,128,240,
  16,240,2,69,85,224,128,240,144,240,2,69,85,240,16,32,
  64,64,2,69,85,240,144,240,144,240,2,69,85,240,144,240,
  16,112,3,19,35,128,0,128};
