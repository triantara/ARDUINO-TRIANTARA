# DFRobot_TCS3472 ColorSensor
DFRobot's Color Sensor mini <br>

Contains the Following:

* Arduino Library & Sample Code
* Hardware Information: <br>
1-Schematic <br>
2-SVG Files <br>