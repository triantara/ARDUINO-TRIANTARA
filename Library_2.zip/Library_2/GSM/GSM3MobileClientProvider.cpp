#include <GSM3MobileClientProvider.h>

GSM3MobileClientProvider* theGSM3MobileClientProvider;