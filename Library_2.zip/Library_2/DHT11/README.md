#DHT11

##What
Humidity & T° sensor

##Source

Library published by [@dalton](https://github.com/adalton/arduino/tree/master/projects/Dht11_Library)

Referenced on the [Arduino playground](http://playground.arduino.cc/Main/DHT11Lib)
